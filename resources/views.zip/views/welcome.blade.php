<?php
$mytime = Carbon\Carbon::now();
echo $mytime->toDateTimeString();