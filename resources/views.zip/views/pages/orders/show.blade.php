@extends('layouts.app')
@section('content')
    <div class="content d-flex flex-column flex-column-fluid" id="kt_content">
        <!--begin::Subheader-->
        <div class="subheader py-2 py-lg-6 subheader-solid" id="kt_subheader">
            <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
                <!--begin::Info-->
                <div class="d-flex align-items-center flex-wrap mr-1">
                    <!--begin::Mobile Toggle-->
                    <button class="burger-icon burger-icon-left mr-4 d-inline-block d-lg-none" id="kt_subheader_mobile_toggle">
                        <span></span>
                    </button>
                    <!--end::Mobile Toggle-->
                    <!--begin::Page Heading-->
                    <div class="d-flex align-items-baseline flex-wrap mr-5">
                        <!--begin::Page Title-->
                        <h5 class="text-dark font-weight-bold my-1 mr-5">{{__('dashboard.Show Record')}}</h5>
                        <!--end::Page Title-->
                        <!--begin::Breadcrumb-->
                        <ul class="breadcrumb breadcrumb-transparent breadcrumb-dot font-weight-bold p-0 my-2 font-size-sm">
                            <li class="breadcrumb-item text-muted">
                                @can('dashboard.index')
                                <a href="{{route('dashboard.index')}}" class="text-muted">{{__('dashboard.Dashboard')}}</a>
                                @endcan
                            </li>
                            <li class="breadcrumb-item text-muted">
                                @can('orders.index')
                                    <a href="{{route('orders.index')}}" class="text-muted">{{__('dashboard.Orders')}}</a>
                                @endcan
                            </li>
                            <li class="breadcrumb-item text-muted">
                                @can('orders.show')
                                <a href={{route('orders.show',$order->id)}}"" class="text-muted">{{__('dashboard.Show Order')}}</a>
                                @endcan
                            </li>
                        </ul>
                        <!--end::Breadcrumb-->
                    </div>
                    <!--end::Page Heading-->
                </div>
                <!--end::Info-->

            </div>
        </div>
        <!--end::Subheader-->
        <!--begin::Entry-->
        <div class="d-flex flex-column-fluid">
            <!--begin::Container-->
            <div class="container">
                <!--begin::Profile Account Information-->
                <div class="d-flex flex-row">

                    <!--begin::Content-->
                    <div class="flex-row-fluid ml-lg-8">
                        <!--begin::Card-->
                        <div class="card card-custom">
                            <!--begin::Header-->
                            <div class="card-header py-3">
                                <div class="card-title align-items-start flex-column">
                                    <h3 class="card-label font-weight-bolder text-dark">{{__('dashboard.Show Order')}}</h3>
                                    <span class="text-muted font-weight-bold font-size-sm mt-1">{{__('dashboard.show order settings')}}</span>
                                </div>
                            </div>
                            <!--end::Header-->
                            <!--begin::Form-->
                            <div class="card card-custom" style="margin-top: 20px">
                                <div class="card-header">
                                    <div class="card-title">
											<span class="card-icon">
												<i class="flaticon2-favourite text-primary"></i>
											</span>
                                        <h3 class="card-label">{{__('dashboard.Order basic Data')}}</h3>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <!--begin: Datatable-->
                                    <table class="table table-bordered table-hover table-checkable table-responsive" id="kt_datatable" style="margin-top: 13px !important">
                                        <thead>
                                        <tr>
                                            <th>{{__('dashboard.User')}}</th>
                                            <th>{{__('dashboard.compnay')}}</th>
                                            <th>{{__('dashboard.worker')}}</th>
                                            <th>{{__('dashboard.package')}}</th>
                                            <th>{{__('dashboard.service')}}</th>
                                            <th>{{__('dashboard.offer')}}</th>
                                            <th>{{__('dashboard.phone')}}</th>
                                            <th>{{__('dashboard.order_number')}}</th>
                                            <th>{{__('dashboard.price')}}</th>
                                            <th>{{__('dashboard.status')}}</th>
                                            <th>{{__('dashboard.payment_status')}}</th>
                                            <th>{{__('dashboard.payment')}}</th>
                                            <th>{{__('dashboard.time')}}</th>
                                            <th>{{__('dashboard.date')}}</th>
                                            <th>{{__('dashboard.visit_time')}}</th>
                                            <th>{{__('dashboard.visit_date')}}</th>
                                            <th>{{__('dashboard.working_hours')}}</th>
                                            <th>{{__('dashboard.finish_time')}}</th>
                                            <th>{{__('dashboard.title')}}</th>
                                            <th>{{__('dashboard.city')}}</th>
                                            <th>{{__('dashboard.notes')}}</th>
                                            <th>{{__('dashboard.apartment_no')}}</th>
                                            <th>{{__('dashboard.floor_no')}}</th>
                                            <th>{{__('dashboard.mark')}}</th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                            <tr>
                                                <td>@if(isset($order->user->name)){{$order->user->name}} @else user not found @endif</td>
                                                <td>@if(isset($order->company->name)){{$order->company->name}} @else company not found @endif</td>
                                                <td>@if(isset($order->worker->name)){{$order->worker->name}} @else worker not found @endif</td>
                                                <td>@if(isset($order->package->name)){{$order->package->name}} @else package not found @endif</td>
                                                <td>@if(isset($order->service->name)){{$order->service->name}} @else service not found @endif</td>
                                                <td>@if(isset($order->offer->name)){{$order->offer->name}} @else offer not found @endif</td>
                                                <td>{{$order->mobile}}</td>
                                                <td>{{$order->order_number}}</td>
                                                <td>{{$order->price}}</td>
                                                <td>@if($order->status==0)
                                                        new
                                                    @elseif($order->status==1)
                                                        in way
                                                    @elseif($order->status==2)
                                                        arrived
                                                    @elseif($order->status==3)
                                                        start processing
                                                    @elseif($order->status==4)
                                                        finished from user
                                                    @elseif($order->status==5)
                                                        finished from worker
                                                    @elseif($order->status==6)
                                                        paid
                                                    @else
                                                        cancelled
                                                    @endif</td>
                                                <td>
                                                  @if($order->payment_status==0)
                                                      not paid yet
                                                    @else
                                                    paid
                                                    @endif
                                                    </td>
                                                <td>{{$order->payment}}</td>
                                                <td>{{$order->time}}</td>
                                                <td>{{$order->date}}</td>

                                                <td>{{$order->visit_time}}</td>
                                                <td>{{$order->visit_date}}</td>
                                                <td>{{intdiv($order->working_hours, 60).':'. ($order->working_hours % 60)}}</td>
                                                <td>{{$order->finish_time}}</td>
                                                <td>{{$order->title}}</td>
                                                <td>{{$order->city}}</td>
                                                <td>{{$order->notes}}</td>
                                                <td>{{$order->apartment_no}}</td>
                                                <td>{{$order->floor_no}}</td>
                                                <td>{{$order->mark}}</td>
                                            </tr>

                                        </tbody>

                                    </table>
                                    <!--end: Datatable-->
                                </div>
                                <!--end::Card-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Card-->
                    </div>
                    <!--end::Content-->
                </div>
                <!--end::Profile Account Information-->
            </div>
            <!--end::Container-->
        </div>


        <!--begin::Card-->

        <!--end::Container-->
    </div>
@endsection
