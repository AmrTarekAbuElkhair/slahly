<h1>Hi, {{ $name }} Welcome to Slahly w shatably Application</h1>
<p>here is message : {{$message}}</p>
<p>Sending Mail from Slahly w shatably Application.</p>
